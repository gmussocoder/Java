/*Curso de Coderhouse: 23240
Estudiante: Guillermo Andrés Musso Rodríguez
e-Mail: gamussorodriguez@teco.com.ar
Teléfono: 1130743868
Fecha: 13/10/2021

****Desafío Uno 1****

*/
let numeroA, numeroB, resultado;
numeroA = Number(prompt("Ingrese un número"));
console.log(numeroA);
numeroB = Number(prompt("Ingrese un número a sumar"));
console.log(numeroB);
resultado = numeroA + numeroB;
document.write("La operación reslizada fue:"+" "+ numeroA + " + " + numeroB + " " + "El resultado es" + " " + resultado);
console.log(resultado);